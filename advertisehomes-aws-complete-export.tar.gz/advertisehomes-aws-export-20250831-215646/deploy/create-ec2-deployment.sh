#!/bin/bash

# AdvertiseHomes.Online EC2 Deployment Script
# For complete AWS deployment including application hosting

set -e

echo "🚀 AdvertiseHomes.Online EC2 Deployment Setup"
echo "AWS Account: 312471576053"
echo "============================================="

# Update system
echo "Updating system packages..."
sudo apt update && sudo apt upgrade -y

# Install Node.js 20.x
echo "Installing Node.js 20.x..."
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt-get install -y nodejs

# Install PostgreSQL client
echo "Installing PostgreSQL client..."
sudo apt-get install -y postgresql-client

# Install Nginx
echo "Installing Nginx..."
sudo apt-get install -y nginx

# Install Certbot for SSL
echo "Installing Certbot for SSL certificates..."
sudo apt-get install -y certbot python3-certbot-nginx

# Create application directory
sudo mkdir -p /opt/advertisehomes
sudo chown -R $USER:$USER /opt/advertisehomes

# Extract application
echo "Setting up application..."
cp -r source/* /opt/advertisehomes/
cd /opt/advertisehomes

# Install dependencies
echo "Installing application dependencies..."
npm install --production

# Build application
echo "Building application..."
npm run build

# Create environment file
echo "Setting up environment..."
sudo mkdir -p /etc/advertisehomes
sudo cp ../config/.env.production /etc/advertisehomes/.env

echo "⚠️  IMPORTANT: Edit /etc/advertisehomes/.env with your actual credentials!"

# Create systemd service
echo "Creating systemd service..."
sudo tee /etc/systemd/system/advertisehomes.service > /dev/null << EOF
[Unit]
Description=AdvertiseHomes.Online Application
After=network.target

[Service]
Type=simple
User=ubuntu
WorkingDirectory=/opt/advertisehomes
Environment=NODE_ENV=production
EnvironmentFile=/etc/advertisehomes/.env
ExecStart=/usr/bin/npm start
Restart=always
RestartSec=10
StandardOutput=syslog
StandardError=syslog
SyslogIdentifier=advertisehomes

[Install]
WantedBy=multi-user.target
EOF

# Configure Nginx
echo "Configuring Nginx..."
sudo tee /etc/nginx/sites-available/advertisehomes > /dev/null << EOF
server {
    listen 80;
    server_name [YOUR-DOMAIN.COM];
    
    # Security headers
    add_header X-Frame-Options DENY;
    add_header X-Content-Type-Options nosniff;
    add_header X-XSS-Protection "1; mode=block";
    
    location / {
        proxy_pass http://localhost:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_cache_bypass \$http_upgrade;
        
        # Increase timeout for long-running requests
        proxy_connect_timeout 60s;
        proxy_send_timeout 60s;
        proxy_read_timeout 60s;
    }
    
    # Handle static assets
    location /assets {
        expires 1y;
        add_header Cache-Control "public, immutable";
    }
}
EOF

sudo ln -sf /etc/nginx/sites-available/advertisehomes /etc/nginx/sites-enabled/
sudo rm -f /etc/nginx/sites-enabled/default

# Test nginx configuration
sudo nginx -t

# Start services
echo "Starting services..."
sudo systemctl daemon-reload
sudo systemctl enable advertisehomes
sudo systemctl start advertisehomes
sudo systemctl restart nginx

# Create monitoring script
cat > /opt/advertisehomes/monitor.sh << 'MONITOR_EOF'
#!/bin/bash
# Simple monitoring script

echo "🔍 AdvertiseHomes.Online Status Check"
echo "===================================="

# Check service status
if systemctl is-active --quiet advertisehomes; then
    echo "✓ Application service: Running"
else
    echo "✗ Application service: Stopped"
fi

# Check nginx status
if systemctl is-active --quiet nginx; then
    echo "✓ Nginx service: Running"
else
    echo "✗ Nginx service: Stopped"
fi

# Check database connection
if curl -s http://localhost:5000/api/platform/stats &> /dev/null; then
    echo "✓ Database connection: Working"
else
    echo "✗ Database connection: Failed"
fi

# Check disk space
DISK_USAGE=$(df -h / | awk 'NR==2{print $5}')
echo "💾 Disk usage: $DISK_USAGE"

# Check memory usage
MEM_USAGE=$(free | grep Mem | awk '{printf("%.1f%%", $3/$2 * 100.0)}')
echo "🧠 Memory usage: $MEM_USAGE"

echo
echo "📊 Application logs (last 10 lines):"
sudo journalctl -u advertisehomes -n 10 --no-pager

MONITOR_EOF

chmod +x /opt/advertisehomes/monitor.sh

echo
echo "✅ EC2 Deployment Complete!"
echo "=========================="
echo
echo "Next steps:"
echo "1. Edit /etc/advertisehomes/.env with your actual credentials"
echo "2. Configure your domain to point to this server"
echo "3. Run: sudo certbot --nginx -d your-domain.com"
echo "4. Test your application"
echo
echo "Monitoring:"
echo "- Check status: /opt/advertisehomes/monitor.sh"
echo "- View logs: sudo journalctl -u advertisehomes -f"
echo "- Service control: sudo systemctl restart advertisehomes"
echo
echo "🎉 Your AdvertiseHomes.Online platform is deployed on AWS!"