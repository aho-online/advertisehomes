#!/bin/bash

# AdvertiseHomes.Online AWS Deployment Script
# Complete deployment to AWS infrastructure

set -e

echo "🚀 AdvertiseHomes.Online AWS Deployment"
echo "AWS Account: 312471576053"
echo "======================================="

# Check if running on AWS EC2
if command -v ec2-metadata &> /dev/null; then
    echo "✓ Running on AWS EC2 instance"
    IS_AWS=true
else
    echo "⚠ Running locally - will configure for AWS deployment"
    IS_AWS=false
fi

# Install Node.js and dependencies
echo "Installing Node.js and dependencies..."
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt-get install -y nodejs postgresql-client nginx

echo "Installing application dependencies..."
cd source
npm install --production

# Build application
echo "Building application..."
npm run build

# Setup systemd service
echo "Creating systemd service..."
sudo tee /etc/systemd/system/advertisehomes.service > /dev/null << SERVICE_EOF
[Unit]
Description=AdvertiseHomes.Online Application
After=network.target

[Service]
Type=simple
User=ubuntu
WorkingDirectory=/opt/advertisehomes/source
Environment=NODE_ENV=production
EnvironmentFile=/opt/advertisehomes/config/.env.production
ExecStart=/usr/bin/npm start
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
SERVICE_EOF

# Copy application to /opt
sudo mkdir -p /opt/advertisehomes
sudo cp -r ../source /opt/advertisehomes/
sudo cp -r ../config /opt/advertisehomes/

# Start service
sudo systemctl daemon-reload
sudo systemctl enable advertisehomes
sudo systemctl start advertisehomes

# Setup nginx reverse proxy
sudo tee /etc/nginx/sites-available/advertisehomes > /dev/null << NGINX_EOF
server {
    listen 80;
    server_name [YOUR-DOMAIN.COM];
    
    location / {
        proxy_pass http://localhost:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_cache_bypass \$http_upgrade;
    }
}
NGINX_EOF

sudo ln -sf /etc/nginx/sites-available/advertisehomes /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl restart nginx

echo "✅ Deployment complete!"
echo "Configure your domain to point to this server's IP address"
echo "Then run: sudo certbot --nginx -d your-domain.com"
