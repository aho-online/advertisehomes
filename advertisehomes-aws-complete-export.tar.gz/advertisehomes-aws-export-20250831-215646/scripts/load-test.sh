#!/bin/bash

# Simple load testing for AdvertiseHomes.Online

DOMAIN=${1:-"localhost:5000"}
PROTOCOL=${2:-"http"}
CONCURRENT=${3:-"10"}
REQUESTS=${4:-"100"}

BASE_URL="${PROTOCOL}://${DOMAIN}"

echo "🚀 Load Testing AdvertiseHomes.Online"
echo "====================================="
echo "URL: $BASE_URL"
echo "Concurrent: $CONCURRENT"
echo "Requests: $REQUESTS"
echo

# Test main page
echo "Testing main page..."
curl -s "$BASE_URL" -w "@curl-format.txt" -o /dev/null

# Test API endpoints
echo "Testing API endpoints..."
curl -s "$BASE_URL/api/platform/stats" -w "@curl-format.txt" -o /dev/null
curl -s "$BASE_URL/api/subscription-plans" -w "@curl-format.txt" -o /dev/null

# Create curl format file
cat > curl-format.txt << FORMAT_EOF
     time_namelookup:  %{time_namelookup}\n
        time_connect:  %{time_connect}\n
     time_appconnect:  %{time_appconnect}\n
    time_pretransfer:  %{time_pretransfer}\n
       time_redirect:  %{time_redirect}\n
  time_starttransfer:  %{time_starttransfer}\n
                     ----------\n
          time_total:  %{time_total}\n
FORMAT_EOF

echo "✅ Load testing complete!"
rm -f curl-format.txt
