#!/bin/bash

# Comprehensive AWS Deployment Testing Script
# Tests all components of AdvertiseHomes.Online

set -e

echo "🧪 AdvertiseHomes.Online AWS Deployment Testing"
echo "==============================================="

DOMAIN=${1:-"localhost:5000"}
PROTOCOL=${2:-"http"}

if [[ "$DOMAIN" != "localhost"* ]]; then
    PROTOCOL="https"
fi

BASE_URL="${PROTOCOL}://${DOMAIN}"

echo "Testing URL: $BASE_URL"
echo

# Colors
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m'

test_pass() {
    echo -e "${GREEN}✓ PASS${NC} $1"
}

test_fail() {
    echo -e "${RED}✗ FAIL${NC} $1"
    FAILED_TESTS=$((FAILED_TESTS + 1))
}

test_warn() {
    echo -e "${YELLOW}⚠ WARN${NC} $1"
}

FAILED_TESTS=0

# Test 1: Basic connectivity
echo "1. Testing basic connectivity..."
if curl -s --max-time 10 "${BASE_URL}" > /dev/null; then
    test_pass "Application is accessible"
else
    test_fail "Cannot reach application"
fi

# Test 2: API health check
echo "2. Testing API health..."
if curl -s --max-time 10 "${BASE_URL}/api/platform/stats" | grep -q "totalProperties"; then
    test_pass "API endpoints responding"
else
    test_fail "API endpoints not working"
fi

# Test 3: Database connectivity
echo "3. Testing database connectivity..."
STATS_RESPONSE=$(curl -s --max-time 10 "${BASE_URL}/api/platform/stats")
if echo "$STATS_RESPONSE" | grep -q "activeAgents"; then
    test_pass "Database connection working"
else
    test_fail "Database connection failed"
fi

# Test 4: Subscription plans
echo "4. Testing subscription plans..."
PLANS_RESPONSE=$(curl -s --max-time 10 "${BASE_URL}/api/subscription-plans")
if echo "$PLANS_RESPONSE" | grep -q "premium"; then
    test_pass "Subscription plans loaded"
    PLAN_COUNT=$(echo "$PLANS_RESPONSE" | grep -o "id" | wc -l)
    echo "   Found $PLAN_COUNT subscription plans"
else
    test_fail "Subscription plans not loading"
fi

# Test 5: Authentication system
echo "5. Testing authentication system..."
AUTH_RESPONSE=$(curl -s --max-time 10 "${BASE_URL}/api/auth/user")
if echo "$AUTH_RESPONSE" | grep -q "Unauthorized" || echo "$AUTH_RESPONSE" | grep -q "id"; then
    test_pass "Authentication system responding"
else
    test_fail "Authentication system not working"
fi

# Test 6: Static asset serving
echo "6. Testing static assets..."
if curl -s --head --max-time 10 "${BASE_URL}/favicon.ico" | grep -q "200\|404"; then
    test_pass "Static asset serving working"
else
    test_fail "Static asset serving failed"
fi

# Test 7: HTTPS (if applicable)
if [[ "$PROTOCOL" == "https" ]]; then
    echo "7. Testing HTTPS configuration..."
    if curl -s --max-time 10 "${BASE_URL}" > /dev/null; then
        test_pass "HTTPS working"
    else
        test_fail "HTTPS not working"
    fi
    
    # Test SSL certificate
    echo "8. Testing SSL certificate..."
    if openssl s_client -connect "${DOMAIN}:443" -servername "${DOMAIN}" < /dev/null 2>/dev/null | grep -q "Verify return code: 0"; then
        test_pass "SSL certificate valid"
    else
        test_warn "SSL certificate issues detected"
    fi
fi

# Test 8: Email service (basic check)
echo "9. Testing email configuration..."
if [[ -n "$SMTP_HOST" && -n "$SMTP_USER" ]]; then
    test_pass "Email configuration present"
else
    test_warn "Email configuration not detected"
fi

# Test 9: Stripe integration (basic check)
echo "10. Testing Stripe integration..."
if [[ -n "$STRIPE_SECRET_KEY" ]]; then
    test_pass "Stripe configuration present"
else
    test_warn "Stripe configuration not detected"
fi

echo
echo "🏁 Testing Complete!"
echo "==================="

if [[ $FAILED_TESTS -eq 0 ]]; then
    echo -e "${GREEN}✅ All tests passed! Deployment is working correctly.${NC}"
    exit 0
else
    echo -e "${RED}❌ $FAILED_TESTS test(s) failed. Please check the issues above.${NC}"
    exit 1
fi
