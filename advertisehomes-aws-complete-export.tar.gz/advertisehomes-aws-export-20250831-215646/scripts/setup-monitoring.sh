#!/bin/bash

# Monitoring Setup for AWS Deployment

echo "📊 Setting up Monitoring for AdvertiseHomes.Online"
echo "================================================="

# Install CloudWatch agent
echo "Installing CloudWatch agent..."
wget https://s3.amazonaws.com/amazoncloudwatch-agent/ubuntu/amd64/latest/amazon-cloudwatch-agent.deb
sudo dpkg -i amazon-cloudwatch-agent.deb

# Create CloudWatch configuration
cat > /opt/aws/amazon-cloudwatch-agent/etc/amazon-cloudwatch-agent.json << CONFIG_EOF
{
    "logs": {
        "logs_collected": {
            "files": {
                "collect_list": [
                    {
                        "file_path": "/var/log/nginx/access.log",
                        "log_group_name": "advertisehomes-nginx-access",
                        "log_stream_name": "{instance_id}"
                    },
                    {
                        "file_path": "/var/log/nginx/error.log",
                        "log_group_name": "advertisehomes-nginx-error",
                        "log_stream_name": "{instance_id}"
                    }
                ]
            },
            "journal": {
                "log_group_name": "advertisehomes-application",
                "log_stream_name": "{instance_id}",
                "filters": [
                    {
                        "type": "include",
                        "expression": "advertisehomes"
                    }
                ]
            }
        }
    },
    "metrics": {
        "namespace": "AdvertiseHomes/Application",
        "metrics_collected": {
            "cpu": {
                "measurement": [
                    "cpu_usage_idle",
                    "cpu_usage_user",
                    "cpu_usage_system"
                ],
                "metrics_collection_interval": 60
            },
            "disk": {
                "measurement": [
                    "used_percent"
                ],
                "metrics_collection_interval": 60,
                "resources": [
                    "*"
                ]
            },
            "mem": {
                "measurement": [
                    "mem_used_percent"
                ],
                "metrics_collection_interval": 60
            }
        }
    }
}
CONFIG_EOF

# Start CloudWatch agent
sudo systemctl enable amazon-cloudwatch-agent
sudo systemctl start amazon-cloudwatch-agent

echo "✅ Monitoring setup complete!"
echo "View logs in AWS CloudWatch console"
