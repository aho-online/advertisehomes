#!/bin/bash

# Database Testing Script for AWS RDS

echo "🗄️ Database Testing for AdvertiseHomes.Online"
echo "============================================="

if [[ -z "$DATABASE_URL" ]]; then
    echo "❌ DATABASE_URL not set"
    exit 1
fi

echo "Database URL: $DATABASE_URL"
echo

# Test 1: Basic connection
echo "1. Testing database connection..."
if psql "$DATABASE_URL" -c "SELECT version();" &> /dev/null; then
    echo "✓ Database connection successful"
else
    echo "✗ Database connection failed"
    exit 1
fi

# Test 2: Table structure
echo "2. Checking table structure..."
TABLE_COUNT=$(psql "$DATABASE_URL" -t -c "SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = 'public';" | xargs)
echo "✓ Found $TABLE_COUNT tables"

# Test 3: Data integrity
echo "3. Checking data integrity..."
USER_COUNT=$(psql "$DATABASE_URL" -t -c "SELECT COUNT(*) FROM users;" | xargs)
PLAN_COUNT=$(psql "$DATABASE_URL" -t -c "SELECT COUNT(*) FROM subscription_plans;" | xargs)
PROPERTY_COUNT=$(psql "$DATABASE_URL" -t -c "SELECT COUNT(*) FROM properties;" | xargs)

echo "✓ Users: $USER_COUNT"
echo "✓ Subscription plans: $PLAN_COUNT"
echo "✓ Properties: $PROPERTY_COUNT"

# Test 4: Sample queries
echo "4. Testing sample queries..."
if psql "$DATABASE_URL" -c "SELECT email, role FROM users LIMIT 5;" &> /dev/null; then
    echo "✓ User queries working"
else
    echo "✗ User queries failed"
fi

# Test 5: Database performance
echo "5. Testing database performance..."
START_TIME=$(date +%s%N)
psql "$DATABASE_URL" -c "SELECT COUNT(*) FROM users; SELECT COUNT(*) FROM properties;" &> /dev/null
END_TIME=$(date +%s%N)
DURATION=$(( (END_TIME - START_TIME) / 1000000 ))
echo "✓ Query performance: ${DURATION}ms"

echo
echo "✅ Database testing complete!"
