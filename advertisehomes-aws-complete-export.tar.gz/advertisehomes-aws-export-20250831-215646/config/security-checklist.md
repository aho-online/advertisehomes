# Security Checklist for AWS Deployment

## Pre-Deployment Security
- [ ] All credentials updated in secrets-template.txt
- [ ] Strong database password chosen (12+ characters, mixed case, numbers, symbols)
- [ ] SESSION_SECRET generated (use: openssl rand -base64 32)
- [ ] AWS IAM user has minimal required permissions
- [ ] Stripe keys are from production account
- [ ] SMTP credentials verified working

## Database Security
- [ ] RDS instance in private subnet (production)
- [ ] Security group restricts access to application servers only
- [ ] SSL/TLS encryption enabled
- [ ] Automated backups configured
- [ ] Point-in-time recovery enabled
- [ ] Database credentials rotated from defaults

## Application Security
- [ ] HTTPS enforced (no HTTP traffic)
- [ ] Secure cookies enabled
- [ ] CSRF protection active
- [ ] Input validation on all endpoints
- [ ] Rate limiting configured
- [ ] Security headers configured in Nginx

## Infrastructure Security
- [ ] EC2 instances in private subnets
- [ ] Load balancer handling public traffic
- [ ] SSH keys instead of passwords
- [ ] Security groups follow least privilege
- [ ] CloudTrail logging enabled
- [ ] VPC flow logs enabled

## Monitoring & Alerting
- [ ] CloudWatch alarms configured
- [ ] Log aggregation setup
- [ ] Error notification alerts
- [ ] Performance monitoring
- [ ] Security incident response plan

## Data Protection
- [ ] Database encryption at rest
- [ ] Application data encryption in transit
- [ ] Regular security updates scheduled
- [ ] Backup encryption enabled
- [ ] Data retention policies defined

## Compliance & Auditing
- [ ] Access logging enabled
- [ ] Audit trail for database changes
- [ ] User activity monitoring
- [ ] Compliance requirements met
- [ ] Security scan completed
