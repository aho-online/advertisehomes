#!/bin/bash

# Credential Rotation Script
# Use this to safely rotate sensitive credentials

echo "🔄 AdvertiseHomes.Online Credential Rotation"
echo "==========================================="

echo "What would you like to rotate?"
echo "1. Database password"
echo "2. Session secret"
echo "3. AWS access keys"
echo "4. All credentials"

read -p "Choose option (1-4): " choice

case $choice in
    1)
        echo "Rotating database password..."
        NEW_DB_PASS=$(openssl rand -base64 20)
        echo "New database password: $NEW_DB_PASS"
        echo "⚠️  Update this in AWS RDS console and environment variables"
        ;;
    2)
        echo "Rotating session secret..."
        NEW_SESSION=$(openssl rand -base64 32)
        echo "New session secret: $NEW_SESSION"
        echo "⚠️  Update SESSION_SECRET in environment variables"
        ;;
    3)
        echo "⚠️  Rotate AWS access keys in AWS IAM console"
        echo "Then update AWS_ACCESS_KEY_ID and AWS_SECRET_ACCESS_KEY"
        ;;
    4)
        echo "Rotating all credentials..."
        NEW_DB_PASS=$(openssl rand -base64 20)
        NEW_SESSION=$(openssl rand -base64 32)
        echo "New database password: $NEW_DB_PASS"
        echo "New session secret: $NEW_SESSION"
        echo "⚠️  Also rotate AWS keys in IAM console"
        echo "⚠️  Update all values in environment variables"
        ;;
    *)
        echo "Invalid option"
        exit 1
        ;;
esac

echo
echo "✅ Rotation complete!"
echo "Remember to update environment variables and restart application"
