#!/bin/bash

# Environment Validation Script
# Checks that all required environment variables are set

echo "🔍 Environment Variables Validation"
echo "==================================="

REQUIRED_VARS=(
    "DATABASE_URL"
    "STRIPE_SECRET_KEY"
    "STRIPE_WEBHOOK_SECRET"
    "VITE_STRIPE_PUBLIC_KEY"
    "SMTP_HOST"
    "SMTP_USER"
    "SMTP_PASSWORD"
    "SESSION_SECRET"
    "AWS_REGION"
    "AWS_ACCOUNT_ID"
)

MISSING_VARS=()

for var in "${REQUIRED_VARS[@]}"; do
    if [[ -z "${!var}" ]]; then
        MISSING_VARS+=($var)
        echo "✗ $var: MISSING"
    else
        echo "✓ $var: SET"
    fi
done

if [[ ${#MISSING_VARS[@]} -eq 0 ]]; then
    echo
    echo "✅ All environment variables are set!"
else
    echo
    echo "❌ Missing environment variables:"
    for var in "${MISSING_VARS[@]}"; do
        echo "  - $var"
    done
    echo
    echo "Please set missing variables before deployment"
    exit 1
fi

# Validate format of specific variables
echo
echo "🔍 Validating Variable Formats"
echo "=============================="

# Database URL format
if [[ $DATABASE_URL =~ ^postgresql://.*@.*:.*/.* ]]; then
    echo "✓ DATABASE_URL: Valid format"
else
    echo "✗ DATABASE_URL: Invalid format"
fi

# Stripe key format
if [[ $STRIPE_SECRET_KEY =~ ^sk_(test|live)_.* ]]; then
    echo "✓ STRIPE_SECRET_KEY: Valid format"
else
    echo "✗ STRIPE_SECRET_KEY: Invalid format"
fi

# Session secret length
if [[ ${#SESSION_SECRET} -ge 32 ]]; then
    echo "✓ SESSION_SECRET: Secure length"
else
    echo "✗ SESSION_SECRET: Too short (minimum 32 characters)"
fi

echo
echo "✅ Environment validation complete!"
